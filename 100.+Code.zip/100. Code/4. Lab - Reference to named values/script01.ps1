$resourceGroupName="staging-grp"
$location="North Europe"

New-AzResourceGroup -Name $resourceGroupName -Location $location